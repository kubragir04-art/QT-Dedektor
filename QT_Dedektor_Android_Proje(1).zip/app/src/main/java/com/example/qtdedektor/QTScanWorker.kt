package com.example.qtdedektor

import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.net.Uri
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.documentfile.provider.DocumentFile
import androidx.work.Worker
import androidx.work.WorkerParameters
import java.io.BufferedInputStream
import java.util.Locale

class QTScanWorker(context: Context, params: WorkerParameters) : Worker(context, params) {
    companion object {
        const val UNIQUE_WORK = "qt_detector_periodic_scan"
        private const val CHANNEL = "qt_matches"
    }

    override fun doWork(): Result {
        val prefs = applicationContext.getSharedPreferences("qt_detector", Context.MODE_PRIVATE)
        val roots = listOf("dcim_uri", "pictures_uri")
            .mapNotNull { prefs.getString(it, null) }
            .mapNotNull { runCatching { DocumentFile.fromTreeUri(applicationContext, Uri.parse(it)) }.getOrNull() }

        if (roots.isEmpty()) return Result.success()

        val seen = prefs.getStringSet("reported_files", emptySet())?.toMutableSet() ?: mutableSetOf()
        var newMatches = 0
        roots.forEach { root -> newMatches += scanTree(root, seen) }

        prefs.edit().putStringSet("reported_files", seen).apply()
        if (newMatches > 0) notifyMatch(newMatches)
        return Result.success()
    }

    private fun scanTree(root: DocumentFile, seen: MutableSet<String>): Int {
        var matches = 0
        val stack = ArrayDeque<DocumentFile>()
        stack.add(root)
        while (stack.isNotEmpty()) {
            if (isStopped) break
            val dir = stack.removeLast()
            val children = try { dir.listFiles() } catch (_: Exception) { emptyArray() }
            for (file in children) {
                if (file.isDirectory) {
                    stack.add(file)
                } else if (file.isFile && isVideoCandidate(file.name)) {
                    val uri = file.uri
                    val signature = "${uri}|${file.length()}|${file.lastModified()}"
                    if (!seen.contains(signature) && hasQuickTimeBrand(uri)) {
                        seen.add(signature)
                        matches++
                    }
                }
            }
        }
        return matches
    }

    private fun isVideoCandidate(name: String?): Boolean {
        val n = name?.lowercase(Locale.ROOT) ?: return false
        return n.endsWith(".mp4") || n.endsWith(".mov") || n.endsWith(".m4v")
    }

    // ISO-BMFF ftyp box: size(4), type(4), major_brand(4).
    // QuickTime files commonly use the literal major_brand "qt  ".
    private fun hasQuickTimeBrand(uri: Uri): Boolean {
        return try {
            applicationContext.contentResolver.openInputStream(uri)?.use { raw ->
                val input = BufferedInputStream(raw)
                val header = ByteArray(16)
                var offset = 0
                while (offset < header.size) {
                    val n = input.read(header, offset, header.size - offset)
                    if (n <= 0) break
                    offset += n
                }
                if (offset < 12) return false
                val boxType = String(header, 4, 4, Charsets.US_ASCII)
                val brand = String(header, 8, 4, Charsets.US_ASCII)
                boxType == "ftyp" && brand.trim() == "qt"
            } ?: false
        } catch (_: Exception) {
            false
        }
    }

    private fun notifyMatch(count: Int) {
        val manager = applicationContext.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= 26) {
            manager.createNotificationChannel(
                NotificationChannel(CHANNEL, "QT video eşleşmeleri", NotificationManager.IMPORTANCE_HIGH)
            )
        }
        val notification = NotificationCompat.Builder(applicationContext, CHANNEL)
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle("QT video bulundu")
            .setContentText("$count yeni videoda major_brand = qt tespit edildi.")
            .setStyle(NotificationCompat.BigTextStyle().bigText("$count yeni videoda QuickTime major_brand (qt) tespit edildi. QT Dedektör uygulamasını açarak tekrar tarama yapabilirsin."))
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setAutoCancel(true)
            .build()
        manager.notify(7001, notification)
    }
}
