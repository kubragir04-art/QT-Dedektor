package com.example.qtdedektor

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.documentfile.provider.DocumentFile
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import java.util.concurrent.TimeUnit

class MainActivity : AppCompatActivity() {
    private val prefs by lazy { getSharedPreferences("qt_detector", MODE_PRIVATE) }
    private lateinit var status: TextView

    private val dcimPicker = registerForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri ->
        saveTree("dcim_uri", uri)
    }
    private val picturesPicker = registerForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri ->
        saveTree("pictures_uri", uri)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildScreen()
        askNotificationPermission()
        refreshStatus()
    }

    private fun buildScreen() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(42, 48, 42, 32)
        }
        fun text(value: String, size: Float = 16f): TextView =
            TextView(this).apply {
                text = value
                textSize = size
                setTextColor(0xFF202124.toInt())
                setPadding(0, 12, 0, 12)
            }
        root.addView(text("QT DEDEKTÖR", 26f))
        root.addView(text("Galeri / DCIM klasörlerini tarar ve MP4 kapsayıcısındaki major_brand değerini kontrol eder."))
        root.addView(text("1) DCIM klasörünü seç", 18f))
        root.addView(Button(this).apply {
            this.text = "DCIM klasörünü seç"
            setOnClickListener { dcimPicker.launch(null) }
        })
        root.addView(text("2) Galeri fotoğraf/video klasörünü seç (genellikle Pictures)", 18f))
        root.addView(Button(this).apply {
            this.text = "Pictures klasörünü seç"
            setOnClickListener { picturesPicker.launch(null) }
        })
        root.addView(Button(this).apply {
            this.text = "Otomatik taramayı başlat (30 dakikada bir)"
            setOnClickListener {
                if (prefs.getString("dcim_uri", null) == null &&
                    prefs.getString("pictures_uri", null) == null) {
                    Toast.makeText(this@MainActivity, "Önce en az bir klasör seç.", Toast.LENGTH_LONG).show()
                } else {
                    val request = PeriodicWorkRequestBuilder<QTScanWorker>(30, TimeUnit.MINUTES).build()
                    WorkManager.getInstance(this@MainActivity).enqueueUniquePeriodicWork(
                        QTScanWorker.UNIQUE_WORK,
                        ExistingPeriodicWorkPolicy.UPDATE,
                        request
                    )
                    Toast.makeText(this@MainActivity, "Otomatik tarama planlandı.", Toast.LENGTH_LONG).show()
                    refreshStatus()
                }
            }
        })
        root.addView(Button(this).apply {
            this.text = "Şimdi tara"
            setOnClickListener {
                WorkManager.getInstance(this@MainActivity)
                    .enqueue(androidx.work.OneTimeWorkRequestBuilder<QTScanWorker>().build())
                Toast.makeText(this@MainActivity, "Tarama başlatıldı.", Toast.LENGTH_SHORT).show()
            }
        })
        root.addView(Button(this).apply {
            this.text = "Otomatik taramayı durdur"
            setOnClickListener {
                WorkManager.getInstance(this@MainActivity).cancelUniqueWork(QTScanWorker.UNIQUE_WORK)
                Toast.makeText(this@MainActivity, "Otomatik tarama durduruldu.", Toast.LENGTH_SHORT).show()
                refreshStatus()
            }
        })
        status = text("Durum yükleniyor…")
        root.addView(status)
        root.addView(text("Not: Android klasör seçicisinde DCIM ve Pictures klasörlerini seçip 'Bu klasörü kullan' izni ver. Galeri uygulamasının kullandığı diğer klasörler için de ayrıca klasör seçebilirsin."))
        setContentView(root)
    }

    private fun saveTree(key: String, uri: Uri?) {
        if (uri == null) return
        try {
            contentResolver.takePersistableUriPermission(
                uri, Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION
            )
        } catch (_: Exception) {
            contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        prefs.edit().putString(key, uri.toString()).apply()
        Toast.makeText(this, "Klasör erişimi kaydedildi.", Toast.LENGTH_SHORT).show()
        refreshStatus()
    }

    private fun refreshStatus() {
        if (!::status.isInitialized) return
        val d = if (prefs.getString("dcim_uri", null) != null) "DCIM: seçildi" else "DCIM: seçilmedi"
        val p = if (prefs.getString("pictures_uri", null) != null) "Pictures: seçildi" else "Pictures: seçilmedi"
        status.text = "$d\\n$p\\nEşleşme: MP4/MOV/M4V dosyasında major_brand = qt"
    }

    private fun askNotificationPermission() {
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.POST_NOTIFICATIONS), 41)
        }
    }
}
