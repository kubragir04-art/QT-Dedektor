# QT Dedektör – Android proje kaynakları

Bu klasör, Tecno K15q / Android 13 için hazırlanmış başlangıç Android Studio projesidir. Hazır APK değildir; Android Studio ile derlenmesi gerekir.

## Özellikler
- Kullanıcının Android klasör seçicisinden verdiği DCIM ve Pictures klasörlerini tarar.
- MP4, MOV ve M4V uzantılı dosyaların ISO-BMFF `ftyp` kutusundaki `major_brand` alanını okur.
- Alan `qt  ` (ekranda `qt`) ise yeni eşleşme bildirimi üretir.
- Dosya URI'si, boyutu ve son değiştirilme zamanına göre aynı sürümü tekrar bildirmez.
- WorkManager ile 30 dakikalık periyodik tarama planlar.

## Derleme
1. Bilgisayara Android Studio (Giraffe veya daha yeni) kur.
2. Bu ZIP'i aç ve `QT_Dedektor_Android` klasörünü Android Studio'da aç.
3. Gradle senkronizasyonunu tamamla.
4. Build > Build Bundle(s) / APK(s) > Build APK(s) seç.
5. APK genellikle `app/build/outputs/apk/debug/app-debug.apk` konumunda oluşur.
6. APK'yı telefona aktar ve kurulum izni ver.

## İlk kullanım
1. Uygulamayı aç ve bildirim iznini ver.
2. "DCIM klasörünü seç" ile Android klasör seçicisinde DCIM klasörünü seç, "Bu klasörü kullan" de.
3. Galeri fotoğraf/video dosyaları Pictures içindeyse Pictures klasörünü de seç.
4. "Şimdi tara" ile ilk taramayı dene.
5. "Otomatik taramayı başlat" ile 30 dakikalık taramayı planla.
6. Tecno pil ayarlarında uygulama için arka plan etkinliğine izin ver; pil tasarrufu taramaları geciktirebilir.

## Teknik sınır
Bu sürüm ilk `ftyp` kutusunun `major_brand` alanını kontrol eder. QuickTime dosyalarında bu alan çoğunlukla `qt  ` olur. Bazı dosyalarda `qt` yerine `isom`, `mp42` veya başka bir brand bulunabilir; bunlar bu sürümde QT olarak işaretlenmez. Bu uygulama video içeriğini oynatmaz veya değiştirmez.
Android 13'te klasör izinleri kullanıcı tarafından verilmelidir. "Pictures" ve "DCIM" ayrı ayrı seçilir. WorkManager periyodik işlerde tam 30 dakika garantisi vermez; Android batarya ve arka plan politikalarına göre çalıştırma zamanını geciktirebilir.
